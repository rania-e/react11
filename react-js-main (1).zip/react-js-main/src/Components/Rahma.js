const Rahma=()=>{
    return(
        <div>
            <h1>A7la Rahma</h1>
        </div>
    )
}

export default Rahma