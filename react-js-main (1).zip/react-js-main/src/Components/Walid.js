import Rahma from "./Rahma"

export const Walid=()=>{
    return(
        <div>
            <h1>A7la Walid</h1>
            <Rahma/>
        </div>
    )
}

export default Walid

// export const Rania=()=>{
//     return(
//         <div>
//             <h1>A7la Rania</h1>
//         </div>
//     )
// }

// // export default Rania