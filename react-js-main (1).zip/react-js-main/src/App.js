import './App.css';
import Walid from './Components/Walid';
// import { Rania, Walid } from './Components/Walid';

function App() {
  return (
    <>
      <h1>Workshop React JS</h1>
      <h2>A7la Wajdi</h2>
      <Walid/>
      {/* <Walid/>
      <Rania/> */}
    </>
   
  );
}

export default App;
